package org.example;

public enum MessageType {
    Broadcast,
    Login
}
