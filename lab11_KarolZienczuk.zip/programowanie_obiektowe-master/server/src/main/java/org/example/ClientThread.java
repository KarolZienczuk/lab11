package org.example;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.net.Socket;

public class ClientThread extends Thread {
    Socket client;
    Server server;
    PrintWriter writer;
    String clientName;

    public static final String BOLD = "\u001B[1m";
    public static final String RESET = "\u001B[0m";
    public static final String YELLOW = "\u001B[33m";
    public static final String BOLD_YELLOW = "\u001B[1;33m";


    public ClientThread(Socket client, Server server) {
        this.client = client;
        this.server = server;
    }

    public String getClientName() {
        return clientName;
    }

    public void run() {
        try {
            InputStream input = client.getInputStream();
            OutputStream output = client.getOutputStream();

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(input)
            );
            writer = new PrintWriter(output,true);



            String rawMessage;
           // "{"type": "", "content": ""}"

            while((rawMessage = reader.readLine()) != null) {
                Message message = new ObjectMapper()
                        .readValue(rawMessage, Message.class);

                switch (message.type) {
                    case Broadcast ->{
                        if (message.content.equals("/online")){
                            sendOnlineUsers(); }
                        else if(message.content.startsWith("/w ")) {
                            handlePrivateMessage(message.content);
                        }
                                else {
                            server.broadcast(new Message(MessageType.Broadcast,BOLD +clientName + ": " + RESET + message.content),this);
                        }
                    }
                    case Login -> login(message.content);
                }
            }


        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            server.removeClient(this);
            if(clientName != null){
                try {
                    Message message = new Message(MessageType.Broadcast,YELLOW +   "Użytkownik " + RESET + BOLD_YELLOW + clientName + RESET + YELLOW + " opuścił czat." + RESET);
                server.broadcast(message,null);
                } catch (JsonProcessingException e){
                    e.printStackTrace();
                }
            } try { client.close(); }
            catch (IOException e){
                e.printStackTrace();
            }
        }
    }

    public void send(Message message) throws JsonProcessingException {
        String rawMessage = new ObjectMapper()
                .writeValueAsString(message);
        writer.println(rawMessage);
    }

    public void login(String name) throws JsonProcessingException {
        clientName = name;
        Message welcomeMessage = new Message(MessageType.Broadcast, "Witaj, " + BOLD + name + RESET);
        send(welcomeMessage);
        Message joinMessage = new Message(MessageType.Broadcast, YELLOW +"Użytkownik " + RESET +  BOLD_YELLOW + name + RESET + YELLOW +" dołączył do czatu." + RESET);
        server.broadcast(joinMessage,this);
    }

    private void sendOnlineUsers() throws JsonProcessingException {

        StringBuilder onlineUsers = new StringBuilder(YELLOW + "Aktualnie zalogowani użytkownicy: " + RESET + BOLD_YELLOW);
        for(ClientThread client : server.getClients()){
            if(client.getClientName() != null){
                onlineUsers.append(client.getClientName()).append(", ");
            }

        }
        onlineUsers.setLength(onlineUsers.length() - 2);
        onlineUsers.append(". " + RESET);
        send(new Message(MessageType.Broadcast,onlineUsers.toString()));
    }
private void handlePrivateMessage(String content) throws JsonProcessingException {
        String[] parts = content.split(" ",3);
        if(parts.length < 3) {
            send(new Message(MessageType.Broadcast, YELLOW  + "Niepoprawna komenda. Użyj /w odbiorca wiadomosc" + RESET));
            return;
        }
        String recipientName = parts[1];
        String privateMessage = parts[2];

        ClientThread recipient = server.getClientByName(recipientName);
        if(recipient != null) {
            recipient.send(new Message(MessageType.Broadcast, BOLD + clientName + " (prywatnie): " + RESET + privateMessage));
        } else {
            send(new Message(MessageType.Broadcast,YELLOW + "Użytkownik " + RESET + BOLD + recipientName + RESET + YELLOW +" nie jest online." + RESET));

        }
}

}
